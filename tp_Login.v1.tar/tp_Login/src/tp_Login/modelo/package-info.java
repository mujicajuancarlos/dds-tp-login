/**
 * 
 */
/**
 * @author juan
 *
 */
package tp_Login.modelo;